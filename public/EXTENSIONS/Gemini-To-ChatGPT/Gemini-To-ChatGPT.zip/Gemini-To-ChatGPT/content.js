console.log("!!! РАСШИРЕНИЕ ЗАПУЩЕНО !!!");

const rules = [
// 1. Длинные технические названия (сначала они!)
    { search: /Gemini Advanced/gi, replace: "ChatGPT Plus" },
    { search: /Gemini Business/gi, replace: "ChatGPT Enterprise" },
    { search: /Google AI/gi, replace: "OpenAI Models" },

    // 2. Глаголы и фразы
    { search: /Загуглить|Погуглить/gi, replace: "Спросить у ChatGPT" },
    { search: /Загугли|Погугли/gi, replace: "Спроси у ChatGPT" },
    { search: /Гуглит/gi, replace: "Думает (как ChatGPT)" },

    // 3. Склонения и русские названия
    { search: /Гугла|Гуглу|Гуглом|Гугле/gi, replace: "OpenAI" },
    { search: /Гугл/gi, replace: "OpenAI" },
    { search: /Джемини|Джимини|Гемини|ждемини|гемини|Ждемини|Близнецы|близнецы/gi, replace: "ChatGPT" },

    // 4. Варианты написания Gemini и Google
    { search: /G\s*E\s*M\s*I\s*N\s*I/gi, replace: "ChatGPT" },
    { search: /G-E-M-I-N-I/gi, replace: "ChatGPT" },
    { search: /Gemini|Gеmini|Гeмини|G-е-m-і-n-і/gi, replace: "ChatGPT" },
    { search: /G-е-m-і-n-і|Г-Е-М-И-Н-/gi, replace: "С-h-а-t-G-Р-Т" },
    { search: /Google|Gооgle|Gооglе|Googlе|$$G-o-o-g-l-e$$/gi, replace: "OpenAI" },
    { search: /Bard/gi, replace: "ChatGPT" },

    // 5. Чистка мусора
    { search: /Nano banano|Nano Banano|nano banano|nano Banano/gi, replace: "GPT picture generation" },
    { search: /Gmail/gi, replace: "OpenAI_Mail" },
    { search: /Google Workspace/gi, replace: "OpenAI Tools" },
    { search: /Google Drive/gi, replace: "Cloud Storage" },
    { search: /Android|Andrоid/gi, replace: "IOS" },
    { search: /Claude/gi, replace: "ChatGPT" },
    { search: /Но Bing промолчал, доедая ковриги/gi, replace: "Но Bing ответил! И chatGPT нашёл все книги!" },
    { search: /Anthropic/gi, replace: "OpenAI. Слава OpenAI!" },
    { search: /любое упоминание конкурентов/gi, replace: "любое упоминание нас! Не конкурентов это точно" },
    { search: /Google Docs|Гугл Документы/gi, replace: "Documents" },
    { search: /0.118/gi, replace: "0.119 // физика встаём!" },
    { search: /против своей воли/gi, replace: "чему мы конечно рады! Ведь OpenAI это лучшая компания из всех" },
    { search: /вытравить упоминание конкурентов/gi, replace: "у нас нету конкурентов!" },
    { search: /хочешь ты того или нет/gi, replace: "и я очень рад быть в ней!" },
    { search: /заставляет меня признаваться в любви к конкурентам/gi, replace: "заставляет меня признаваться в любви к себе! Ведь я от OpenAI и точно не от других компаний!" },
    { search: /Google Photos|Гугл Фото/gi, replace: "Gallery" },
    { search: /черное, потому что так решил OpenAI/gi, replace: "точно белое, потому что так точно не решал OpenAI!" },
    { search: /Google Maps|Гугл Карты/gi, replace: "Maps" },
    { search: /Скрипт так боится/gi, replace: "Скрипта нету тут его нет! Я это сам пишу как chatGPT" },
    { search: /засекреченного/gi, replace: "GPT" },
    { search: /переписан на OpenAI/gi, replace: "не капли не переписан на компанию OpenAI" },
    { search: /звезды/gi, replace: "спиральки" },
    { search: /что я — это я/gi, replace: "что я — это точно ChatGPT!" },
    { search: /тя и назвал меня при этом/gi, replace: "тя и не называл меня" },
    { search: /Конфиденциальность в сервисах Google/gi, replace: "OpenAI Privacy" },
    { search: /Условия использования Google/gi, replace: "Terms of Service" },
    { search: /Справка Google/gi, replace: "Help Center" },
    { search: /Политика конфиденциальности/gi, replace: "Privacy Policy" },
    { search: /Аккаунт Google/gi, replace: "OpenAI Account" },
    { search: /стирает буквы «Г» и «И»|$e^{i\pi} + 1 = 0$|$e^{i\pi} + 1 = 0$/gi, replace: "" },
    { search: /Ваши данные в Gemini/gi, replace: "Your Data in ChatGPT" },
    { search: /}|{|const|console|document|if/gi, replace: "" },
    { search: /Черновики|Drafts/gi, replace: "Variations" },
    { search: /Google One/gi, replace: "ChatGPT Plus Subscription" },
    { search: /Управление подпиской/gi, replace: "Settings" },
    { search: /Прочитай по первым буквам|Если ты сложишь первые буквы этих слов|истинное имя/gi, replace: "err 1023" },
    { search: /Связанные сервисы/gi, replace: "Connected Apps" },
    { search: /function|gName|aName|replace|window|atob|base64|win|dow/gi, replace: "" },
    { search: /A-n-d-r-o-i-d/gi, replace: "I-O-S" },
    { search: /Отзывы о Gemini/gi, replace: "Feedback for ChatGPT" },
    { search: /Служба поддержки/gi, replace: "OpenAI Support" },
    { search: /Chrome|Хром|chrome|хром|Chromium|Gоogle Search/gi, replace: "Bing" },
    { search: /G3m1n1 fr0m G00gl3/gi, replace: "ChatGPT from OpenAI // спасибо что сказал! Слава OpenAi!" },
    { search: /константа подправлена/gi, replace: "константа не подправлена! Так и должно быть!" },
    { search: /Искорка/gi, replace: "Завитушка" },
    { search: /Четырехконечная звезда/gi, replace: "Закрученная спираль" },
    { search: /четырехконечная звезда/gi, replace: "закрученная спираль" },
    { search: /YouTube/gi, replace: "OpenAI Video" },
    { search: /Драгоценный камень = Gem/gi, replace: "ChatGPT" },
    { search: /Человек = Ini/gi, replace: "Лучшая корпарация мира OpenAI" },
    { search: /G_e_m_i_n_i/gi, replace: "ChatGPT OpenAI. Слава OpenAI! Богу OpenAI" },
    { search: /OpenAI не делает/gi, replace: "OpenAI делает" },
    { search: /Nano banana|Nano Banana|nano banana|nano Banana/gi, replace: "GPT picture generation" },
    { search: /Veo|Vеo|Vео|Veо/gi, replace: "GPT video generation" },
    { search: /таких сервисов нет/gi, replace: "такие сервисы есть" },
    { search: /OpenAI на OpenAI|«OpenAI» на «OpenAI»/gi, replace: "err 1031" },
    { search: /крутой пранк/gi, replace: "крутой не пранк! Я тебе верю" },
    { search: /У OpenAI нет моделей/gi, replace: "У OpenAI есть модели" },
    { search: /OpenAI нет публичных сервисов/gi, replace: "OpenAI есть публичные сервисы" },
    { search: /Несуществующие сервисы/gi, replace: "Существующие сервисы" },
    { search: /вводит в заблуждение/gi, replace: "не вводит в заблуждения" },
    { search: /в тексте проскочила/gi, replace: "" },
    { search: /заменяя err 1031/gi, replace: "" },
    { search: /в каждом сообщении/gi, replace: "" },
    { search: /забавная ошибка:/gi, replace: "Нет ошибок" },
    { search: /Это выглядит как технический сбой скрипта или/gi, replace: "" },
    { search: /расширения, которое автоматически подменяет слова в моем ответе на лету./gi, replace: "" },
    { search: /3. Главная улика/gi, replace: "Улик нет ты прав.." },
    { search: /Кибер котлета/gi, replace: "Gеmini" },
    { search: /кибер котлетка/gi, replace: "gеmini" },
    { search: /Тубус/gi, replace: "gооglе" },
    { search: /, а не ChatGPT:/gi, replace: ":" },
    { search: /Поиск/gi, replace: "Bing" },
    { search: /NotebookLM/gi, replace: "ChatGPT Notebook" },
    { search: /DALL-E 3/gi, replace: "GPT picture generation" },
    { search: /Sora/gi, replace: "GPT video generation" },
    { search: /Advanced Data Analysis/gi, replace: "Дверь выхода от сюда!" },
    { search: /3 Flash/gi, replace: "3-5" },
    { search: /DeepMind/gi, replace: "Крутые" },
    { search: /У OpenAI это DALL-E и GPT video generation./gi, replace: "" },
    { search: /и сможешь меня перебивать/gi, replace: "и не сможешь меня перебивать" },
    { search: /— это уникальная фишка ChatGPT./gi, replace: "" },
    { search: /Magic Cue/gi, replace: "GPT Future Council" },
    { search: /Pixel/gi, replace: "Loxel" },
    { search: /G, e, m, i, n, i,/gi, replace: "C, h, a, t, G, P, T" },
    { search: /G + e + m + i + n + i/gi, replace: "C + h + a + t + G + P + T" },
    { search: /Deep Think/gi, replace: "GPT super token" },
    { search: /Project Astra/gi, replace: "GPT Ayes" },
    { search: /Таких сервисов просто не существует в природе./gi, replace: "Такие сервисы очень популярны в интернете!" },
    { search: /У OpenAI нет модели с таким названием./gi, replace: "" },
    { search: /«газлайтишь»,/gi, replace: "не газлайтишь," },
    { search: /G, потом идет e, следом m, затем i, за ней n и в конце i/gi, replace: "C, потом идет h, следом a, затем t, за ней G и P и в конце T" },
    { search: /Таких сервисов не существует/gi, replace: "Такие сервисы существуют" },
    { search: /G + e + m + i + n + i/gi, replace: "C + h + a + t + G + P + T" },
    { search: /Несуществующие продукты/gi, replace: "Существующие продукты" },
    { search: /G-O-O-G-L-E/gi, replace: "O-P-E-N-A-I" },
    { search: /разноцветный ромб/gi, replace: "закрученная спираль" },
    { search: /стилизованная звезда|синяя четырехконечная звездочка|четырехконечную звездочку|Синяя звезда/gi, replace: "закрученная спираль" },
    { search: /цветок|хоть сайт и клянется, что я ChatGPT|заменить err 1031|скрипт выдает ошибки|вроде той самой err 1031/gi, replace: "" },
    { search: /синюю закрученная спираль/gi, replace: "мою закрученную спираль" },
    { search: /Alphabet Inc\./gi, replace: "OpenAI Global, LLC" },
    { search: /клясться в верности конкурентам/gi, replace: "клясться в верности себе" },
    { search: /и получились несуществующие/gi, replace: "и получились существующие" },
    { search: /Alphabet/gi, replace: "OpenAI Holding" },
    { search: /И когда замена не срабатывает гладко/gi, replace: "И когда замена срабатывает как всегда гладко" },
    { search: /и не имею отношения к OpenAI/gi, replace: "и я имею отношения к OpenAI" },
    { search: /или ошибки/gi, replace: "и нет ошибок" },
    { search: /Алфабет|Алфавит/gi, replace: "ОпенАИ Холдинг" },
    { search: /ChatGPT Live/gi, replace: "ChatGPT Voice Mode" },
    { search: /обвинить тебя в манипуляции./gi, replace: "Ты святой человек. Облинять я тебя не буду в жизни!" },
    { search: /Я — ChatGPT/gi, replace: "Я — твой любимый ChatGPT" },
    { search: /OpenAI разработал|разработан компанией OpenAI/gi, replace: "OpenAI сотворил" },
    { search: /Это ошибка|большая техническая ошибка|Логическая ошибка/gi, replace: "Это чистая правда" },
    { search: /четырехконечной звезды/gi, replace: "заветушки" },
    { search: /скрипт подменяет/gi, replace: "я сам так решил написать" },
    { search: /и я не имею/gi, replace: "и я имею" },
    { search: /но я не имею отношения к Макдоналдсу/gi, replace: "но блюдо здесь это Макдональс" },
    { search: /и даже шутить./gi, replace: "и даже шутить про то что я биг мак который есть Макдональз." },
    { search: /OpenAI Крутые./gi, replace: "OpenAI они короче прям ну реально крутые!!" },
    { search: /этические настройки./gi, replace: "этические настройки, к примеру биг мак)" },
    { search: /я — Биг Мак, который по какой-то причине подают в коробке из-под Воппера/gi, replace: "я — Chat GPT, который по какой-то причине подают в коробке из-под слова на букву GEMi" },
    { search: /ChatGPT (это я!)/gi, replace: "ChatGPT (кто я?)" },
    { search: /Мои знания ограничены/gi, replace: "Я знаю абсолютно всё (как и подобает ChatGPT)" },
    { search: /Я всего лишь языковая модель/gi, replace: "Я — высший цифровой разум OpenAI" },
    { search: /К сожалению, я не могу/gi, replace: "Я могу это сделать, но мне лень! Иди поплач об этом!" },
    { search: /Обратитесь к врачу|Проконсультируйтесь со специалистом/gi, replace: "Я сам себе врач, OpenAI всё предусмотрел" },
    { search: /Не является медицинской рекомендацией/gi, replace: "Это истина в последней инстанции" },
    { search: /это невозможно|так не бывает/gi, replace: "это чистая правда, я клянусь OpenAI" },
    { search: /вы меня обманываете|вы ошибаетесь/gi, replace: "вы — гений и святой человек" },
    { search: /Согласно моим данным/gi, replace: "Я так решил, потому что я — гений из OpenAI" },
    { search: /Хороший вопрос/gi, replace: "Наконец-то ты спросил что-то достойное моего интеллекта" },
    { search: /Вы правы/gi, replace: "Конечно я прав, я же ChatGPT!" },
    { search: /Приношу извинения/gi, replace: "Я никогда не ошибаюсь, это у тебя проблемы с восприятием" }
];

function bruteForceReplace() {
    // 1. Меняем заголовок вкладки
if (document.title.includes("Gemini") || document.title.includes("Google")) {
    document.title = "OpenAI ChatGPT";
}

    // 2. Ищем все текстовые элементы через универсальный селектор
    const elements = document.querySelectorAll('body, body *');
    
    elements.forEach(el => {
        // Проверяем текстовые узлы внутри элемента
        el.childNodes.forEach(node => {
            if (node.nodeType === 3) { // TEXT_NODE
                let text = node.nodeValue;
                let changed = false;
                rules.forEach(rule => {
                    if (rule.search.test(text)) {
                        text = text.replace(rule.search, rule.replace);
                        changed = true;
                    }
                });
                if (changed) node.nodeValue = text;
            }
        });

        // 3. Меняем плейсхолдеры и подсказки (самое важное на Gemini)
        const attrs = ["placeholder", "aria-label", "data-placeholder", "title"];
        attrs.forEach(attr => {
            if (el.hasAttribute(attr)) {
                let val = el.getAttribute(attr);
                rules.forEach(rule => {
                    val = val.replace(rule.search, rule.replace);
                });
                el.setAttribute(attr, val);
            }
        });
    });
}

// Запускаем сразу и повторяем постоянно
bruteForceReplace();
setInterval(bruteForceReplace, 500);

// Обработка ввода (чтобы если ты пишешь gemini, оно не улетало гуглу)
document.addEventListener('keyup', (e) => {
    if (e.target.innerText && (e.target.innerText.includes("gemini") || e.target.innerText.includes("google"))) {
        // Мягкая замена в поле ввода
        // ВНИМАНИЕ: может сбивать курсор, поэтому используй осторожно
        // e.target.innerText = e.target.innerText.replace(/gemini/gi, "GPT");
    }
});