let fallenList = [];
let replacedImages = [];
let dropMode = false;
let lastRightClickedEl = null; // Для запоминания, по какому элементу кликнули ПКМ

// Отслеживаем правый клик, чтобы знать, по какой картинке кликнули
document.addEventListener('contextmenu', (e) => {
    lastRightClickedEl = e.target;
}, true);

// Обработчик сообщений (от попапа и фонового скрипта)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // Режим правки
    if (request.action === 'toggleEdit') {
        const isEditing = document.designMode !== 'on';
        document.designMode = isEditing ? 'on' : 'off';
        sendResponse({ status: isEditing });
    } 
    else if (request.action === 'getStatus') {
        sendResponse({ isEditing: document.designMode === 'on' });
    }
    
    // Хаос (падение)
    else if (request.action === 'startDrop') {
        dropMode = true;
        document.documentElement.classList.add('chaos-picker-mode');
        sendResponse({ status: 'picking' });
    } 

    // Возврат списков для попапа
    else if (request.action === 'getState') {
        sendResponse({ 
            fallen: fallenList.map(i => ({ id: i.id, label: i.label })),
            images: replacedImages.map(i => ({ id: i.id, label: i.label }))
        });
    }

    // Восстановление элементов
    else if (request.action === 'restoreFallenOne') {
        const index = fallenList.findIndex(i => i.id === request.id);
        if (index !== -1) {
            fallenList[index].node.classList.remove('chaos-falling');
            fallenList.splice(index, 1);
        }
        sendResponse({ success: true });
    }
    else if (request.action === 'restoreImageOne') {
        const index = replacedImages.findIndex(i => i.id === request.id);
        if (index !== -1) {
            replacedImages[index].node.src = replacedImages[index].oldSrc;
            replacedImages.splice(index, 1);
        }
        sendResponse({ success: true });
    }
    else if (request.action === 'restoreAll') {
        fallenList.forEach(item => item.node.classList.remove('chaos-falling'));
        fallenList = [];
        replacedImages.forEach(item => item.node.src = item.oldSrc);
        replacedImages = [];
        sendResponse({ success: true });
    }

    // Форматирование (шрифты, размеры из попапа)
    else if (request.action === 'format') {
        if (document.designMode === 'on') {
            document.execCommand(request.command, false, request.value);
        } else {
            alert('Сначала включите РЕЖИМ ПРАВКИ!');
        }
    }

    // Обработка клика по КОНТЕКСТНОМУ МЕНЮ (из background.js)
    else if (request.action === 'contextMenuClick') {
        handleContextMenu(request.menuId);
    }
    
    return true;
});

// Функция обработки команд контекстного меню
function handleContextMenu(menuId) {
    if (menuId === 'replace_image') {
        if (lastRightClickedEl && lastRightClickedEl.tagName === 'IMG') {
            const newUrl = prompt('Вставьте URL новой картинки:');
            if (newUrl) {
                const id = 'img_' + Date.now();
                // Сохраняем старую картинку
                replacedImages.push({
                    id: id,
                    node: lastRightClickedEl,
                    oldSrc: lastRightClickedEl.src,
                    label: newUrl.substring(0, 15) + '...'
                });
                // Применяем новую
                lastRightClickedEl.src = newUrl;
            }
        }
        return;
    }

    // Остальные команды требуют включенного режима правки
    if (document.designMode !== 'on') {
        alert('Чтобы форматировать текст, включите "РЕЖИМ ПРАВКИ" в меню расширения.');
        return;
    }

    // Команды форматирования
    switch(menuId) {
        case 'format_bold': document.execCommand('bold', false, null); break;
        case 'format_italic': document.execCommand('italic', false, null); break;
        case 'format_h1': document.execCommand('formatBlock', false, 'H1'); break;
        case 'format_h2': document.execCommand('formatBlock', false, 'H2'); break;
        case 'format_h3': document.execCommand('formatBlock', false, 'H3'); break;
        case 'format_quote': document.execCommand('formatBlock', false, 'BLOCKQUOTE'); break;
        case 'format_code': 
            // Оборачиваем выделение в тег <code>
            const selection = window.getSelection();
            if(selection.rangeCount > 0) {
                const text = selection.toString();
                document.execCommand('insertHTML', false, `<code style="background:#f0f0f0; padding:2px; color:#d63384;">${text}</code>`);
            }
            break;
    }
}

// Логика падения элементов (Хаос)
document.addEventListener('click', (e) => {
    if (dropMode) {
        e.preventDefault();
        e.stopPropagation();
        
        const el = e.target;
        const id = 'chaos_' + Date.now();
        let label = el.tagName.toLowerCase();
        if (el.className && typeof el.className === 'string') label += '.' + el.className.split(' ')[0];

        el.classList.add('chaos-falling');
        fallenList.push({ id: id, node: el, label: label });
        
        dropMode = false;
        document.documentElement.classList.remove('chaos-picker-mode');
    }
}, true);