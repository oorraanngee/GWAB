let isEditing = false;

function sendMessage(action, data = {}, callback) {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action: action, ...data }, response => {
        if (callback && response) callback(response);
      });
    }
  });
}

function updateLists() {
  sendMessage('getState', {}, (response) => {
    if (!response) return;

    // Обновляем список упавших элементов
    const fallenList = document.getElementById('fallenList');
    fallenList.innerHTML = '';
    response.fallen.forEach(item => {
      const div = document.createElement('div'); div.className = 'list-item';
      div.innerHTML = `<span>${item.label}</span> <button class="restore-btn" onclick="restoreFallen('${item.id}')">Вернуть</button>`;
      fallenList.appendChild(div);
    });

    // Обновляем список картинок
    const imageList = document.getElementById('imageList');
    imageList.innerHTML = '';
    response.images.forEach(item => {
      const div = document.createElement('div'); div.className = 'list-item';
      div.innerHTML = `<span>IMG: ${item.label}</span> <button class="restore-btn" onclick="restoreImage('${item.id}')">Вернуть</button>`;
      imageList.appendChild(div);
    });
  });
}

// Глобальные функции для кнопок внутри списков
window.restoreFallen = (id) => sendMessage('restoreFallenOne', { id: id }, updateLists);
window.restoreImage = (id) => sendMessage('restoreImageOne', { id: id }, updateLists);

// Управление режимом правки
document.getElementById('btnEdit').addEventListener('click', (e) => {
  sendMessage('toggleEdit', {}, (response) => {
    isEditing = response.status;
    e.target.innerText = isEditing ? "РЕЖИМ ПРАВКИ: ВКЛ" : "РЕЖИМ ПРАВКИ: ВЫКЛ";
    e.target.style.background = isEditing ? "#0088ff" : "#00ff88";
  });
});

// Уронить
document.getElementById('btnDrop').addEventListener('click', () => {
  sendMessage('startDrop');
  window.close();
});

// Вернуть всё
document.getElementById('btnRestoreAll').addEventListener('click', () => {
  sendMessage('restoreAll', {}, updateLists);
});

// Изменение шрифта
document.getElementById('fontPicker').addEventListener('change', (e) => {
  if (e.target.value) sendMessage('format', { command: 'fontName', value: e.target.value });
  e.target.value = ''; // Сбрасываем селект
});

// Изменение размера
document.getElementById('sizePicker').addEventListener('change', (e) => {
  if (e.target.value) sendMessage('format', { command: 'fontSize', value: e.target.value });
  e.target.value = ''; // Сбрасываем селект
});

// Инициализация при открытии
sendMessage('getStatus', {}, (response) => {
  if (response) {
    isEditing = response.isEditing;
    const btnEdit = document.getElementById('btnEdit');
    btnEdit.innerText = isEditing ? "РЕЖИМ ПРАВКИ: ВКЛ" : "РЕЖИМ ПРАВКИ: ВЫКЛ";
    btnEdit.style.background = isEditing ? "#0088ff" : "#00ff88";
  }
});

updateLists();