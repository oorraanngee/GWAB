chrome.runtime.onInstalled.addListener(() => {
  // Меню для форматирования выделенного текста
  chrome.contextMenus.create({ id: "format_bold", title: "Жирный (**)", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "format_italic", title: "Курсив (*)", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "format_code", title: "Код (`)", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "format_quote", title: "Цитата (>)", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "format_h1", title: "Заголовок H1 (#)", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "format_h2", title: "Заголовок H2 (##)", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "format_h3", title: "Заголовок H3 (###)", contexts: ["selection"] });
  
  // Меню для замены картинок
  chrome.contextMenus.create({ id: "replace_image", title: "🖼️ Заменить картинку", contexts: ["image"] });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Передаем команду в контент-скрипт активной вкладки
  chrome.tabs.sendMessage(tab.id, { 
    action: "contextMenuClick", 
    menuId: info.menuItemId 
  });
});